import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { signoutuser } from "../../redux/authSlice";
import { useNavigate } from "react-router-dom";
import { Link, useLocation } from "react-router-dom";
import {
  AiOutlineMenu,
  AiOutlineClose,
  AiOutlineDashboard,
} from "react-icons/ai";
import { MdAccountTree } from "react-icons/md";
import { PiHandDepositFill, PiHandWithdrawFill } from "react-icons/pi";
import {
  FaHandHoldingDollar,
  FaDirections,
  FaRegUser,
  FaMoneyBillTransfer,
} from "react-icons/fa6";
import { IoMdNotifications, IoMdLogOut } from "react-icons/io";
import { GiLevelEndFlag } from "react-icons/gi";
import { SiFirewalla } from "react-icons/si";
import { TbListDetails } from "react-icons/tb";
import { BiSolidUserPin, BiDetail, BiSolidUserDetail } from "react-icons/bi";
import { MdKey } from "react-icons/md";
import { BiTask } from "react-icons/bi";
import { FaChartBar, FaHistory } from "react-icons/fa";
import {
  DocumentChartBarIcon,
  UserGroupIcon,
} from "@heroicons/react/24/outline";
import { FcSupport } from "react-icons/fc";
import { Disclosure } from "@headlessui/react";
import { defaulterNotification, getUser } from "../../redux/userSlice";
import NotificationPopup from "../../User/NotificationPopup";
import RewardNotification from "../../User/RewardNotification";
import { GrDown } from "react-icons/gr";
import { Wallet } from "lucide-react";

const income = [
  {
    name: "Adds Income",
    to: "/transactions/add_income",
    icon: <TbListDetails className="w-6 h-6" />,
  },
  {
    name: "Telegram",
    to: "/transactions/telegram_income",
    icon: <AiOutlineDashboard className="w-6 h-6" />,
  },
  {
    name: "Sponsor",
    to: "/transactions/sponsor_income",
    icon: <AiOutlineDashboard className="w-6 h-6" />,
  },

  {
    name: "ROI Income",
    to: "/transactions/roi_income",
    icon: <GiLevelEndFlag className="w-6 h-6" />,
  },
  {
    name: "Direct Income",
    to: "/user/transaction/direct_transaction",
    icon: <GiLevelEndFlag className="w-6 h-6" />,
  },
  {
    name: "Level",
    to: "/user/transaction/invest_level_transaction/invest",
    icon: <GiLevelEndFlag className="w-6 h-6" />,
  },
  {
    name: "Reward",
    to: "/user/transaction/reward_transaction",
    icon: <FaHistory className="w-6 h-6" />,
  },
  {
    name: "Detail",
    to: "/user/income",
    icon: <TbListDetails className="w-6 h-6" />,
  },
];
const kyc = [
  {
    name: "KYC Charge",
    to: "/user/UserKycCharge",
    icon: <FaChartBar className="w-6 h-6" />,
  },
  {
    name: "KYC Details",
    to: "/user/UserKycDetails",
    icon: <BiDetail className="w-6 h-6" />,
  },
  {
    name: "KYC Transfer",
    to: "/user/UserKycTransfer",
    icon: <FaMoneyBillTransfer className="w-6 h-6" />,
  },
  {
    name: "KYC History",
    to: "/user/UserKycHistory",
    icon: <FaHistory className="w-6 h-6" />,
  },
];
const team = [
  {
    name: "Tree View",
    to: "/user/referraltree",
  },
  {
    name: "Team ",
    to: "/user/directmember",
  },
];

const menus = [
  {
    name: "Dashboard",
    to: "/user/dashboard",
    icon: <AiOutlineDashboard className="w-6 h-6" />,
  },
  {
    name: "View Ad",
    to: "/watch-adds",
    icon: <BiTask className="w-6 h-6" />,
  },
  {
    name: "Tree",
    to: "/user/referraltree",
    icon: <MdAccountTree className="w-6 h-6" />,
    submenu: team,
  },
  {
    name: "Deposit",
    to: "/user/adddeposite",
    icon: <PiHandDepositFill className="w-6 h-6" />,
  },
  {
    name: "Income",
    to: "/user/income",
    icon: <FaHandHoldingDollar className="w-6 h-6" />,
    submenu: income,
  },
  {
    name: "kyc",
    to: "/user/income",
    icon: <MdKey className="w-6 h-6" />,
    submenu: kyc,
  },

  {
    name: "Withdrawal",
    to: "/user/addwithdrawal",
    icon: <PiHandWithdrawFill className="w-6 h-6" />,
  },
  {
    name: "Notification",
    to: "/user/Notification",
    icon: <IoMdNotifications className="w-6 h-6" />,
  },
  {
    name: "ReTop-Up",
    to: "/user/topup",
    icon: <DocumentChartBarIcon className="w-6 h-6" />,
  },
  {
    name: "Membership Plan",
    to: "/user/plan",
    icon: <UserGroupIcon className="w-6 h-6" />,
  },
  {
    name: "Support",
    to: "/user/sendsupport",
    icon: <FcSupport className="w-6 h-6" />,
  },
  {
    name: "Kyc",
    to: "/user/UserKyc",
    icon: <BiSolidUserPin className="w-6 h-6" />,
  },

  {
    name: " Bank Details",
    to: "/user/UserBankDetails",
    icon: <BiSolidUserDetail className="w-6 h-6" />,
  },
];

export default function UserMenu({ Children }) {
  const [expanded, setExpanded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const [activeTab, setActiveTab] = useState("Dashboard");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [defaulternotification, setDefaulterNotification] = useState(false);
  const { auth } = useSelector((state) => state.auth);
  const { singleuser, userrewardnotification } = useSelector(
    (state) => state.allusers
  );

  const [tabs, setTabs] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [currentMenu, setCurrentMenu] = useState("Dashboard");
  const [currentTabs, setCurrentTabs] = useState(tabs?.[0]);
  const [timeRemaining, setTimeRemaining] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  const [timeRemaining2, setTimeRemaining2] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  // Check if screen is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth < 768) {
        setExpanded(false);
      }
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  useEffect(() => {
    dispatch(getUser(auth?.id));
    dispatch(defaulterNotification(auth?.id));
  }, [auth?.id]);

  useEffect(() => {
    if (userrewardnotification) {
      setDefaulterNotification(true);
    }
  }, [userrewardnotification]);

  function handleLogout() {
    dispatch(signoutuser());
    navigate("/");
  }

  function handleMenu(submenu, name) {
    setTabs(submenu);
    setCurrentMenu(name);
  }

  useEffect(() => {
    if (!singleuser?.created_at) return;
    const createdAtDate = new Date(singleuser.created_at);
    const referenceDate = new Date("2025-02-08T00:00:00Z"); // 7 Feb 2025 (UTC)
    if (createdAtDate < referenceDate) {
      setTimeRemaining({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      return;
    }

    const timerDuration = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds
    const endDate = createdAtDate.getTime() + timerDuration;

    const calculateTimeRemaining = () => {
      const now = new Date().getTime();
      const difference = endDate - now;

      if (difference <= 0) {
        clearInterval(timerInterval);
        setTimeRemaining({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      } else {
        setTimeRemaining({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor(
            (difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
          ),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        });
      }
    };

    const timerInterval = setInterval(calculateTimeRemaining, 1000);
    return () => clearInterval(timerInterval);
  }, [singleuser?.created_at]);

  useEffect(() => {
    if (!singleuser?.created_at) return;

    const createdAtDate = new Date(singleuser.created_at);
    const referenceDate = new Date("2025-02-08T00:00:00Z"); // 7 Feb 2025 (UTC)

    // If created_at is before 7th Feb 2025, stop the countdown
    if (createdAtDate < referenceDate) {
      setTimeRemaining2({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      return;
    }

    const timerDuration2 = 7 * 24 * 60 * 60 * 1000;
    const endDate2 = createdAtDate.getTime() + timerDuration2;

    const calculateTimeRemaining2 = () => {
      const now = new Date().getTime();
      const difference2 = endDate2 - now;

      if (difference2 <= 0) {
        clearInterval(timerInterval2);
        setTimeRemaining2({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      } else {
        setTimeRemaining2({
          days: Math.floor(difference2 / (1000 * 60 * 60 * 24)),
          hours: Math.floor(
            (difference2 % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
          ),
          minutes: Math.floor((difference2 % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference2 % (1000 * 60)) / 1000),
        });
      }
    };

    const timerInterval2 = setInterval(calculateTimeRemaining2, 1000);
    return () => clearInterval(timerInterval2);
  }, [singleuser?.created_at]);

  function isClose() {
    setDefaulterNotification(false);
  }

  return (
    <div className="flex min-h-screen">
      {/* Left Sidebar - collapsible */}
      <aside
        className={`fixed left-0 top-0 h-screen bg-white text-gray-900 shadow-lg z-40 transition-all duration-300 ${
          isMobile ? (sidebarOpen ? "w-64" : "w-0") : expanded ? "w-64" : "w-16"
        } overflow-hidden`}
        onMouseEnter={() => !isMobile && setExpanded(true)}
        onMouseLeave={() => !isMobile && setExpanded(false)}
      >
        {/* Logo and User Info */}
        <div
          className={`flex flex-col items-center p-4 bg-white transition-all duration-300 ${
            expanded || sidebarOpen ? "justify-start" : "justify-center"
          }`}
        >
          <div className="flex justify-center items-center mb-2 w-10 h-10">
            <img src="/teirrax.png" className="w-10" alt="Logo" />
          </div>
          {/* <div className="text-black">okk</div> */}
          {(expanded || sidebarOpen) && (
            <>
              <p className="mt-2 text-lg font-bold">
                {singleuser?.refferal_code}
              </p>
              <p className="text-sm text-gray-800">{singleuser?.fullname}</p>
            </>
          )}
        </div>

        {/* Close button - only on mobile */}
        {isMobile && sidebarOpen && (
          <button
            className="absolute top-4 right-4 text-gray-900"
            onClick={() => setSidebarOpen(false)}
          >
            <AiOutlineClose className="w-6 h-6" />
          </button>
        )}

        {/* Navigation Menu */}
        <nav className="flex-1 overflow-y-auto p-2 mb-10 no-scrollbar max-h-[calc(100vh-6rem)]">
          {menus.map((menu, index) =>
            menu.submenu ? (
              <Disclosure key={index}>
                {({ open }) => (
                  <>
                    <Disclosure.Button
                      className={`flex items-center justify-between w-full p-3 rounded hover:bg-[#e1eaff] transition my-1 ${
                        location.pathname === menu.to ? "bg-[#e1eaff]" : ""
                      }`}
                    >
                      <div className="flex items-center">
                        <div className="flex-shrink-0">{menu.icon}</div>
                        {(expanded || sidebarOpen) && (
                          <span className="ml-3">{menu.name}</span>
                        )}
                      </div>
                      {(expanded || sidebarOpen) && (
                        <span
                          className={`transform transition-transform ${
                            open ? "rotate-180" : "rotate-0"
                          }`}
                        >
                          <GrDown className="w-4 h-4" />
                        </span>
                      )}
                    </Disclosure.Button>

                    {/* Apply scrolling to submenu when it exceeds height */}
                    <Disclosure.Panel
                      className={`overflow-y-auto pl-4 mt-1 max-h-60 ${
                        !expanded && !sidebarOpen ? "hidden" : ""
                      }`}
                    >
                      {menu.submenu.map((sub, i) => (
                        <Link
                          key={i}
                          to={sub.to}
                          className={`flex items-center p-2 rounded hover:bg-[#e1eaff] transition my-1 ${
                            location.pathname === sub.to ? "bg-[#e1eaff]" : ""
                          }`}
                          onClick={() => isMobile && setSidebarOpen(false)}
                        >
                          <div className="flex-shrink-0">{sub.icon}</div>
                          {(expanded || sidebarOpen) && (
                            <span className="ml-3">{sub.name}</span>
                          )}
                        </Link>
                      ))}
                    </Disclosure.Panel>
                  </>
                )}
              </Disclosure>
            ) : (
              <Link
                key={index}
                to={menu.to}
                className={`flex items-center p-3 rounded hover:bg-[#e1eaff] transition my-1 ${
                  location.pathname === menu.to ? "bg-[#e1eaff]" : ""
                }`}
                onClick={() => isMobile && setSidebarOpen(false)}
              >
                <div className="flex-shrink-0">{menu.icon}</div>
                {(expanded || sidebarOpen) && (
                  <span className="ml-3">{menu.name}</span>
                )}
              </Link>
            )
          )}
          <Link
            to={`/user/profile/${auth?.id}`}
            className={`flex items-center p-3 rounded hover:bg-[#e1eaff] transition my-1 ${
              location.pathname === `/user/profile/${auth?.id}`
                ? "bg-[#e1eaff]"
                : ""
            }`}
            onClick={() => isMobile && setSidebarOpen(false)}
          >
            <FaRegUser className="w-5 h-5" />
            {(expanded || sidebarOpen) && <span className="ml-3">Profile</span>}
          </Link>

          <button
            onClick={handleLogout}
            className="flex items-center p-3 my-1 w-full text-red-500 rounded transition hover:bg-red-100"
          >
            <IoMdLogOut className="w-5 h-5" />
            {(expanded || sidebarOpen) && <span className="ml-3">Logout</span>}
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <div
        className={`flex-1 transition-all duration-300 ${
          isMobile ? "" : expanded ? "ml-64" : "ml-16"
        }`}
      >
        {/* Mobile Header */}
        <header className="w-full bg-[#fafafa] shadow-md text-gray-900 py-4 px-4 flex justify-between items-center sticky top-0 z-30">
          <Link to="/" className="flex items-center">
            <img
              src="https://img.freepik.com/free-photo/portrait-expressive-young-woman_1258-48167.jpg?uid=R90634854&ga=GA1.1.1673403856.1719407260&semt=ais_hybrid&w=740"
              className="w-14"
              alt="Logo"
            />
          </Link>
          <div className="text-black flex gap-4">
            <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-xl shadow-md transition duration-300">
              ${singleuser?.business}
            </button>
            <button className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-xl shadow-md transition duration-300">
              ${singleuser?.wallet}
            </button>
          </div>

          <div className="flex flex-col justify-center items-center px-5">
            <p className="mt-2 text-lg font-bold">
              {singleuser?.refferal_code}
            </p>
            <p className="text-sm text-gray-800">{singleuser?.fullname}</p>
          </div>

          {isMobile && (
            <button
              className="px-3 py-2 text-black bg-blue-200 rounded-sm border border-blue-400 shadow-lg"
              onClick={() => setSidebarOpen(true)}
            >
              <AiOutlineMenu className="w-6 h-6" />
            </button>
          )}
        </header>

        {/* Main Content Area */}
        <div className="w-full bg-[#eeeeeefa] text-gray-800 min-h-screen ">
          <div className="w-full h-full bg-gradient-to-br from-green-100 via-pink-100 to-gray-100">
            {Children}
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      {isMobile && (
        <nav className="fixed bottom-0 left-0 w-full z-40 bg-[#fafafa] shadow-lg text-gray-900 border-t border-black/20">
          <div className="flex justify-between px-4 py-3 mx-auto">
            {menus.slice(0, 4).map((menu, index) => (
              <Link
                key={index}
                to={menu.to}
                className={`flex flex-col items-center text-sm ${
                  location.pathname === menu.to
                    ? "text-[#0089bd]"
                    : "text-gray-800"
                }`}
              >
                {menu.icon}
                <span className="text-xs font-semibold">{menu.name}</span>
              </Link>
            ))}
            <Link
              to={`/user/profile/${auth?.id}`}
              className={`flex flex-col items-center text-sm ${
                location.pathname === `/user/profile/${auth?.id}`
                  ? "text-[#0089bd]"
                  : "text-gray-800"
              }`}
            >
              <FaRegUser className="w-5 h-5" />
              <span className="mt-1 text-xs font-semibold">Profile</span>
            </Link>
            <button
              onClick={handleLogout}
              className="flex flex-col items-center text-sm text-red-400"
            >
              <IoMdLogOut className="w-5 h-5 text-red-400" />
              <span className="mt-1 text-xs font-semibold">Logout</span>
            </button>
          </div>
        </nav>
      )}
    </div>
  );
}
